# The Journey of Us — Her Birthday Website

A full interactive birthday experience: countdown, memory timeline, love quiz, mystery
gift boxes, future dreams, "why I love you" hearts, spin-the-wheel, an interactive sky
of memories/promises/compliments, a mood-based letter generator, a secret password gate,
and a fireworks + confetti finale with a downloadable certificate.

## Files
- `index.html` — all page structure/content
- `style.css` — all visual styling (night-sky / constellation theme)
- `script.js` — all interactivity
- `assets/` — put your photos, song, and QR code here

## How to personalize (search for "EDIT HERE" in the files)

1. **Her name** — replace every `[ HER NAME ]` in `index.html` (homepage hero + finale + certificate).

2. **Background music** — `script.js` line near the top, and `index.html`'s `<audio>` tag.
   Add your file as `assets/her-favorite-song.mp3` (keep that exact filename, or update both
   the HTML `<source src="...">` and you're done — no JS change needed).

3. **Countdown date** — `script.js`, search `birthdayDate`. Change the year/month/day/hour.
   **Note: month is 0-indexed** (0 = January, 11 = December).

4. **Memory Lane** — `index.html`, section `#memory-lane`. Four cards: replace the
   `[ Date ]` and `[ Write a short... ]` placeholder text. For photos, replace
   `<div class="memory-photo placeholder" data-caption="...">` with
   `<div class="memory-photo" style="background-image:url('assets/memory-1.jpg')">`
   (repeat for memory-2.jpg, memory-3.jpg, memory-4.jpg).

5. **Love Quiz** — `index.html`, section `#quiz`. For each question:
   - Replace the bracketed option text with your real options.
   - `data-correct="N"` tells the script which option (0, 1, or 2) is correct —
     update the number if you reorder the answers.

6. **Gift Boxes** — `script.js`, search `giftContent`. Replace the placeholder text
   inside `letter`, `video`, `coupon`, and `photo` with your real content. For the
   photo, add `assets/hidden-photo.jpg` and update the path the same way as Memory Lane.

7. **Future Dreams** — `index.html`, section `#future-dreams`. Replace the four
   `<p>[ ... ]</p>` lines with your real reasons/descriptions.

8. **Why I Love You hearts** — `index.html`, section `#why-i-love-you`. Each
   `data-msg="..."` attribute holds the message that pops up when she taps that heart.

9. **Spin the Wheel** — `script.js`, search `wheelPrizes` to change the five prizes.

10. **Interactive Sky** — `script.js`, search `skyStarData`. Eight stars, each with a
    `tag` (Memory / Promise / Compliment) and `text` — replace with real content.

11. **Mood Letters** — `script.js`, search `moodLetters`. Three templates (happy/sad/excited)
    — personalize the wording in your own voice.

12. **Secret Password** — `script.js`, search `correctPassword`. Currently set to
    `'sunshine'` as a placeholder — change it to her real nickname. The check is
    case-insensitive, so don't worry about capitalization.

13. **Final message** — `index.html`, section `#finale`, the `.finale-message` paragraph.
    This is the big one — write your real birthday message here.

14. **Birthday video** — `index.html`, finale section, `.video-wrap.placeholder` div.
    Replace with a YouTube/Drive embed:
    `<div class="video-wrap"><iframe src="YOUR_EMBED_URL" allowfullscreen></iframe></div>`

15. **Final QR code** — generate one for free at qr-code-generator.com pointing to
    a video, letter PDF, or location link. Save as `assets/final-qr.png`, then replace
    the `.qr-wrap.placeholder` div with:
    `<div class="qr-wrap"><img src="assets/final-qr.png" style="width:100%;height:100%;border-radius:12px;"></div>`

## How to host it (so you can actually send her a link)

Easiest free options:
- **Netlify Drop**: go to app.netlify.com/drop, drag the whole folder in, get an instant link.
- **GitHub Pages**: push the folder to a GitHub repo, enable Pages in repo settings.
- **Vercel**: similar drag-and-drop deploy via vercel.com.

All three are free and give you a real shareable URL in under 2 minutes.

## Notes
- Works on mobile and desktop. The side constellation nav hides on small screens
  (under 768px) to keep things uncluttered — she'll navigate by scrolling.
- The "Finale" nav dot starts locked and unlocks once the secret password is solved.
- Everything is plain HTML/CSS/JS — no build step, no dependencies, no server needed.
