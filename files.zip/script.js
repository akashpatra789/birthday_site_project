/* =================================================================
   THE JOURNEY OF US — script
   All interactive logic. Search "EDIT HERE" for personalization spots.
   ================================================================= */

document.addEventListener('DOMContentLoaded', () => {

  /* ================= AMBIENT NIGHT SKY (canvas stars) ================= */
  const skyCanvas = document.getElementById('sky');
  const skyCtx = skyCanvas.getContext('2d');
  let stars = [];

  function resizeSky() {
    skyCanvas.width = window.innerWidth;
    skyCanvas.height = document.documentElement.scrollHeight;
  }

  function makeStars() {
    const count = Math.floor((skyCanvas.width * skyCanvas.height) / 9000);
    stars = Array.from({ length: count }, () => ({
      x: Math.random() * skyCanvas.width,
      y: Math.random() * skyCanvas.height,
      r: Math.random() * 1.4 + 0.3,
      twinkleSpeed: Math.random() * 0.02 + 0.005,
      phase: Math.random() * Math.PI * 2
    }));
  }

  function drawSky() {
    skyCtx.clearRect(0, 0, skyCanvas.width, skyCanvas.height);
    const t = Date.now() * 0.001;
    stars.forEach(s => {
      const alpha = 0.4 + 0.6 * Math.abs(Math.sin(t * s.twinkleSpeed * 10 + s.phase));
      skyCtx.beginPath();
      skyCtx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      skyCtx.fillStyle = `rgba(250,246,240,${alpha})`;
      skyCtx.fill();
    });
    requestAnimationFrame(drawSky);
  }

  resizeSky();
  makeStars();
  drawSky();
  window.addEventListener('resize', () => { resizeSky(); makeStars(); });

  /* shooting stars, occasional */
  const shootingWrap = document.getElementById('shooting-stars');
  function spawnShootingStar() {
    const star = document.createElement('div');
    star.className = 'shooting-star';
    star.style.top = Math.random() * 40 + '%';
    star.style.left = (60 + Math.random() * 35) + '%';
    shootingWrap.appendChild(star);
    setTimeout(() => star.remove(), 2600);
  }
  setInterval(spawnShootingStar, 4500);

  /* ================= CONSTELLATION NAV ================= */
  const navItems = document.querySelectorAll('#constellation-list li');
  const chapters = document.querySelectorAll('.chapter');

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      if (item.classList.contains('locked')) return;
      const target = document.getElementById(item.dataset.target);
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    });
  });

  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navItems.forEach(li => li.classList.remove('active'));
        const match = document.querySelector(`#constellation-list li[data-target="${entry.target.id}"]`);
        if (match) match.classList.add('active');
      }
    });
  }, { threshold: 0.5 });

  chapters.forEach(ch => sectionObserver.observe(ch));

  document.getElementById('begin-journey').addEventListener('click', () => {
    document.getElementById('memory-lane').scrollIntoView({ behavior: 'smooth' });
  });

  /* ================= MUSIC TOGGLE (YouTube background music) ================= */
  // EDIT HERE: her favorite song's YouTube video ID (the part after "v=" in the URL)
  const YT_VIDEO_ID = 'YOUR_VIDEO_ID_HERE';

  const musicBtn = document.getElementById('music-toggle');
  let ytPlayer = null;
  let ytReady = false;
  let musicPlaying = false;

  // YouTube IFrame API calls this global function automatically once loaded
  window.onYouTubeIframeAPIReady = function () {
    ytPlayer = new YT.Player('yt-player', {
      height: '1',
      width: '1',
      videoId: YT_VIDEO_ID,
      playerVars: { autoplay: 0, loop: 1, playlist: YT_VIDEO_ID, controls: 0 },
      events: {
        onReady: () => { ytReady = true; }
      }
    });
  };

  musicBtn.addEventListener('click', () => {
    if (!ytReady || !ytPlayer) {
      console.log('Music player still loading, try again in a second.');
      return;
    }
    if (!musicPlaying) {
      ytPlayer.playVideo();
      musicBtn.classList.add('playing');
      musicBtn.setAttribute('aria-pressed', 'true');
    } else {
      ytPlayer.pauseVideo();
      musicBtn.classList.remove('playing');
      musicBtn.setAttribute('aria-pressed', 'false');
    }
    musicPlaying = !musicPlaying;
  });

  /* ================= COUNTDOWN TIMER ================= */
  // EDIT HERE: her actual birthday (month is 0-indexed: 0 = Jan, 11 = Dec)
  const birthdayDate = new Date(2026, 0, 1, 0, 0, 0); // placeholder: Jan 1, 2026

  function updateCountdown() {
    const now = new Date();
    let diff = birthdayDate - now;
    if (diff < 0) diff = 0;

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const mins = Math.floor((diff / (1000 * 60)) % 60);
    const secs = Math.floor((diff / 1000) % 60);

    document.getElementById('cd-days').textContent = String(days).padStart(2, '0');
    document.getElementById('cd-hours').textContent = String(hours).padStart(2, '0');
    document.getElementById('cd-mins').textContent = String(mins).padStart(2, '0');
    document.getElementById('cd-secs').textContent = String(secs).padStart(2, '0');
  }
  updateCountdown();
  setInterval(updateCountdown, 1000);

  /* ================= LOVE QUIZ ================= */
  const quizQuestions = document.querySelectorAll('.quiz-question');
  const quizResult = document.getElementById('quiz-result');
  const quizProgressFill = document.getElementById('quiz-progress-fill');
  let currentQ = 0;

  function showQuestion(index) {
    quizQuestions.forEach(q => q.classList.remove('active'));
    if (index < quizQuestions.length) {
      quizQuestions[index].classList.add('active');
    } else {
      quizResult.classList.add('show');
    }
    quizProgressFill.style.width = `${(index / quizQuestions.length) * 100}%`;
  }

  quizQuestions.forEach((question) => {
    const optionsWrap = question.querySelector('.q-options');
    const correctIndex = parseInt(optionsWrap.dataset.correct, 10);
    const options = optionsWrap.querySelectorAll('.q-opt');

    options.forEach((opt, i) => {
      opt.addEventListener('click', () => {
        if (opt.disabled) return;
        options.forEach(o => o.disabled = true);
        if (i === correctIndex) {
          opt.classList.add('correct');
          setTimeout(() => {
            currentQ++;
            showQuestion(currentQ);
          }, 700);
        } else {
          opt.classList.add('wrong');
          options[correctIndex].classList.add('correct');
          setTimeout(() => {
            currentQ++;
            showQuestion(currentQ);
          }, 1000);
        }
      });
    });
  });

  /* ================= MYSTERY GIFT BOXES ================= */
  // EDIT HERE: replace these four content blocks with your real letter/video/coupon/photo
  const giftContent = {
    letter: `
      <h3>💌 A Love Letter</h3>
      <p>[ Write your love letter here. ]</p>
    `,
    video: `
      <h3>🎥 A Video Message</h3>
      <p>Just for you.</p>
      <video controls style="width:100%;border-radius:12px;margin-top:1rem;" src="assets/gift-video.mp4"></video>
    `,
    coupon: `
      <h3>🎟️ A Coupon</h3>
      <div class="coupon-box">
        <p style="font-family:'Playfair Display',serif;font-size:1.3rem;color:#F2C66D;">[ Coupon reward ]</p>
        <p style="margin-top:0.5rem;font-size:0.85rem;">[ Coupon terms, e.g. "Redeemable anytime." ]</p>
      </div>
    `,
    photo: `
      <h3>📷 A Hidden Photo</h3>
      <p>[ Caption for the photo. ]</p>
      <div class="memory-photo placeholder" data-caption="Add photo: assets/hidden-photo.jpg" style="margin-top:1rem;"></div>
    `
  };

  const giftModal = document.getElementById('gift-modal');
  const giftModalContent = document.getElementById('gift-modal-content');

  document.querySelectorAll('.gift-box').forEach(box => {
    box.addEventListener('click', () => {
      const key = box.dataset.gift;
      giftModalContent.innerHTML = giftContent[key] || '<p>Coming soon.</p>';
      giftModal.classList.add('show');
      box.classList.add('opened');
    });
  });

  document.getElementById('gift-modal-close').addEventListener('click', () => {
    giftModal.classList.remove('show');
  });
  giftModal.addEventListener('click', (e) => {
    if (e.target === giftModal) giftModal.classList.remove('show');
  });

  /* ================= WHY I LOVE YOU (floating hearts) ================= */
  const heartModal = document.getElementById('heart-modal');
  const heartModalText = document.getElementById('heart-modal-text');

  document.querySelectorAll('.floating-heart').forEach(heart => {
    heart.addEventListener('click', () => {
      heartModalText.textContent = heart.dataset.msg;
      heartModal.classList.add('show');
    });
  });

  document.getElementById('heart-modal-close').addEventListener('click', () => {
    heartModal.classList.remove('show');
  });
  heartModal.addEventListener('click', (e) => {
    if (e.target === heartModal) heartModal.classList.remove('show');
  });

  /* ================= SPIN THE WHEEL ================= */
  // EDIT HERE: change these prize labels if you want different rewards
  const wheelPrizes = ['Prize 1 🍫', 'Prize 2 🎢', 'Prize 3 🚗', 'Prize 4 🎁', 'Prize 5 🤗'];
  const wheelColors = ['#1B2147', '#2A3166', '#1B2147', '#2A3166', '#1B2147'];
  const wheelSvg = document.getElementById('wheel-svg');
  const wheelEl = document.getElementById('wheel');
  const spinBtn = document.getElementById('spin-btn');
  const wheelResult = document.getElementById('wheel-result');
  const sliceAngle = 360 / wheelPrizes.length;
  let currentRotation = 0;
  let spinning = false;

  function polarToCartesian(cx, cy, r, angleDeg) {
    const angleRad = (angleDeg - 90) * Math.PI / 180;
    return { x: cx + r * Math.cos(angleRad), y: cy + r * Math.sin(angleRad) };
  }

  function buildWheel() {
    const cx = 150, cy = 150, r = 145;
    let svgMarkup = '';
    wheelPrizes.forEach((prize, i) => {
      const startAngle = i * sliceAngle;
      const endAngle = startAngle + sliceAngle;
      const start = polarToCartesian(cx, cy, r, startAngle);
      const end = polarToCartesian(cx, cy, r, endAngle);
      const largeArc = sliceAngle > 180 ? 1 : 0;
      svgMarkup += `<path d="M${cx},${cy} L${start.x},${start.y} A${r},${r} 0 ${largeArc} 1 ${end.x},${end.y} Z" fill="${wheelColors[i % wheelColors.length]}" stroke="#0B0E23" stroke-width="1"/>`;

      const midAngle = startAngle + sliceAngle / 2;
      const labelPos = polarToCartesian(cx, cy, r * 0.62, midAngle);
      svgMarkup += `<text x="${labelPos.x}" y="${labelPos.y}" fill="#FAF6F0" font-size="9" font-family="Quicksand, sans-serif" text-anchor="middle" transform="rotate(${midAngle}, ${labelPos.x}, ${labelPos.y})">${prize.split(' ')[0]}</text>`;
    });
    wheelSvg.innerHTML = svgMarkup;
  }
  buildWheel();

  spinBtn.addEventListener('click', () => {
    if (spinning) return;
    spinning = true;
    wheelResult.textContent = '';

    const prizeIndex = Math.floor(Math.random() * wheelPrizes.length);
    // Calculate rotation so the pointer (top) lands within the chosen slice
    const targetSliceCenter = prizeIndex * sliceAngle + sliceAngle / 2;
    const fullSpins = 5 * 360;
    const finalRotation = fullSpins + (360 - targetSliceCenter);

    currentRotation += finalRotation;
    wheelEl.style.transform = `rotate(${currentRotation}deg)`;

    setTimeout(() => {
      wheelResult.textContent = `You won: ${wheelPrizes[prizeIndex]}`;
      spinning = false;
    }, 4100);
  });

  /* ================= INTERACTIVE SKY (memories/promises/compliments) ================= */
  // EDIT HERE: replace these with real memories, promises, and compliments
  const skyStarData = [
    { tag: 'Memory', text: '[ Write a memory. ]' },
    { tag: 'Compliment', text: '[ Write a compliment. ]' },
    { tag: 'Promise', text: '[ Write a promise. ]' },
    { tag: 'Memory', text: '[ Write a memory. ]' },
    { tag: 'Compliment', text: '[ Write a compliment. ]' },
    { tag: 'Promise', text: '[ Write a promise. ]' },
    { tag: 'Memory', text: '[ Write a memory. ]' },
    { tag: 'Compliment', text: '[ Write a compliment. ]' }
  ];

  const interactiveSky = document.getElementById('interactive-sky');
  skyStarData.forEach((data, i) => {
    const star = document.createElement('button');
    star.className = 'sky-star';
    star.style.left = (5 + (i * 12) % 90) + '%';
    star.style.top = (10 + (i * 37) % 75) + '%';
    star.style.animationDelay = (i * 0.3) + 's';
    star.dataset.tag = data.tag;
    star.dataset.text = data.text;
    star.setAttribute('aria-label', `Reveal a ${data.tag.toLowerCase()}`);
    interactiveSky.appendChild(star);
  });

  const starModal = document.getElementById('star-modal');
  const starModalTag = document.getElementById('star-modal-tag');
  const starModalText = document.getElementById('star-modal-text');

  interactiveSky.addEventListener('click', (e) => {
    const star = e.target.closest('.sky-star');
    if (!star) return;
    starModalTag.textContent = star.dataset.tag;
    starModalText.textContent = star.dataset.text;
    starModal.classList.add('show');
  });

  document.getElementById('star-modal-close').addEventListener('click', () => {
    starModal.classList.remove('show');
  });
  starModal.addEventListener('click', (e) => {
    if (e.target === starModal) starModal.classList.remove('show');
  });

  /* ================= AI MOOD LETTER GENERATOR ================= */
  // EDIT HERE: customize these letter templates in her/your own voice
  const moodLetters = {
    happy: "[ Write a message for when she's feeling happy. ]",
    sad: "[ Write a message for when she's feeling sad. ]",
    excited: "[ Write a message for when she's feeling excited. ]"
  };

  const moodLetterBox = document.getElementById('mood-letter-box');
  document.querySelectorAll('.mood-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.mood-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      moodLetterBox.textContent = moodLetters[btn.dataset.mood];
    });
  });

  /* ================= SECRET PASSWORD ================= */
  // EDIT HERE: set the correct nickname (case-insensitive comparison, so don't worry about capitalization)
  const correctPassword = 'sunshine';

  const passwordForm = document.getElementById('password-form');
  const passwordInput = document.getElementById('password-input');
  const passwordFeedback = document.getElementById('password-feedback');
  const finaleNavItem = document.querySelector('#constellation-list li[data-target="finale"]');

  passwordForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const guess = passwordInput.value.trim().toLowerCase();
    if (guess === correctPassword.toLowerCase()) {
      passwordFeedback.style.color = '#6CC28D';
      passwordFeedback.textContent = 'Correct. Unlocking your finale...';
      if (finaleNavItem) finaleNavItem.classList.remove('locked');
      setTimeout(() => {
        document.getElementById('finale').scrollIntoView({ behavior: 'smooth' });
        triggerFireworks();
        triggerConfetti();
      }, 900);
    } else {
      passwordFeedback.style.color = '#F2A6B3';
      passwordFeedback.textContent = "Not quite — try again.";
    }
  });

  /* ================= CERTIFICATE DATE + DOWNLOAD ================= */
  document.getElementById('cert-date').textContent =
    `Awarded on ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}`;

  document.getElementById('download-cert').addEventListener('click', () => {
    const cert = document.getElementById('certificate');
    const text = cert.innerText;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'certificate-of-amazing-girlfriend.txt';
    a.click();
    URL.revokeObjectURL(url);
  });

  /* ================= CONTINUE BUTTON ================= */
  // EDIT HERE: customize the response message
  document.getElementById('continue-btn').addEventListener('click', () => {
    document.getElementById('continue-response').textContent = 'Always. Every single day. 💕';
  });

  /* ================= FIREWORKS (finale canvas) ================= */
  const fireworksCanvas = document.getElementById('fireworks-canvas');
  const fwCtx = fireworksCanvas.getContext('2d');
  let fireworkParticles = [];
  let fireworksRunning = false;

  function resizeFireworks() {
    const finale = document.getElementById('finale');
    fireworksCanvas.width = finale.offsetWidth;
    fireworksCanvas.height = finale.offsetHeight;
  }
  window.addEventListener('resize', resizeFireworks);

  function createFirework(x, y) {
    const colors = ['#F2C66D', '#F2A6B3', '#FAF6F0', '#6CC2E0'];
    const color = colors[Math.floor(Math.random() * colors.length)];
    const count = 40;
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count;
      const speed = 1.5 + Math.random() * 2.5;
      fireworkParticles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        alpha: 1,
        color
      });
    }
  }

  function animateFireworks() {
    fwCtx.clearRect(0, 0, fireworksCanvas.width, fireworksCanvas.height);
    fireworkParticles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.04;
      p.alpha -= 0.012;
      fwCtx.beginPath();
      fwCtx.arc(p.x, p.y, 2, 0, Math.PI * 2);
      fwCtx.fillStyle = p.color.replace(')', '').replace('#', '#');
      fwCtx.globalAlpha = Math.max(p.alpha, 0);
      fwCtx.fillStyle = p.color;
      fwCtx.fill();
    });
    fwCtx.globalAlpha = 1;
    fireworkParticles = fireworkParticles.filter(p => p.alpha > 0);

    if (fireworksRunning) requestAnimationFrame(animateFireworks);
  }

  function triggerFireworks() {
    resizeFireworks();
    fireworksRunning = true;
    let bursts = 0;
    const burstInterval = setInterval(() => {
      const x = Math.random() * fireworksCanvas.width;
      const y = Math.random() * fireworksCanvas.height * 0.6 + 20;
      createFirework(x, y);
      bursts++;
      if (bursts >= 8) clearInterval(burstInterval);
    }, 500);
    animateFireworks();
    setTimeout(() => { fireworksRunning = false; }, 6000);
  }

  /* ================= CONFETTI (simple CSS-based) ================= */
  function triggerConfetti() {
    const wrap = document.getElementById('confetti-canvas-wrap');
    const colors = ['#F2C66D', '#F2A6B3', '#FAF6F0', '#6CC2E0'];
    for (let i = 0; i < 60; i++) {
      const piece = document.createElement('div');
      const size = 6 + Math.random() * 6;
      piece.style.position = 'absolute';
      piece.style.top = '-20px';
      piece.style.left = Math.random() * 100 + '%';
      piece.style.width = size + 'px';
      piece.style.height = size * 0.4 + 'px';
      piece.style.background = colors[Math.floor(Math.random() * colors.length)];
      piece.style.opacity = '0.9';
      piece.style.borderRadius = '2px';
      piece.style.transform = `rotate(${Math.random() * 360}deg)`;
      piece.style.zIndex = '3';
      piece.style.animation = `confetti-fall ${3 + Math.random() * 2}s linear forwards`;
      piece.style.animationDelay = (Math.random() * 1.2) + 's';
      wrap.appendChild(piece);
      setTimeout(() => piece.remove(), 6000);
    }
  }

  // Confetti fall keyframes injected dynamically (keeps CSS file clean)
  const styleTag = document.createElement('style');
  styleTag.textContent = `
    @keyframes confetti-fall {
      0% { transform: translateY(0) rotate(0deg); opacity: 0.9; }
      100% { transform: translateY(110vh) rotate(360deg); opacity: 0; }
    }
  `;
  document.head.appendChild(styleTag);

});
